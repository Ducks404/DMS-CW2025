package com.tetris.input;

import javafx.scene.input.KeyCode;

public class CreativeGameInputMap extends BaseInputMap {
    public CreativeGameInputMap() {
        map.put(KeyCode.UP, EventType.MOVE_UP);
        map.put(KeyCode.LEFT, EventType.MOVE_LEFT);
        map.put(KeyCode.RIGHT, EventType.MOVE_RIGHT);
        map.put(KeyCode.DOWN, EventType.MOVE_DOWN);
        map.put(KeyCode.R, EventType.MOVE_ROTATE);
        map.put(KeyCode.H, EventType.THROW);
        map.put(KeyCode.SPACE, EventType.PLACE);
        map.put(KeyCode.N, EventType.NEW_GAME);
        map.put(KeyCode.ESCAPE, EventType.EXIT);
    }
}
