package com.tetris.view;

import com.tetris.SceneManager;
import com.tetris.viewmodel.SettingsViewModel;
import com.tetris.viewmodel.ViewModel;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

import java.net.URL;
import java.util.ResourceBundle;

public class GuiController implements Initializable {

    @FXML
    private VBox controlsPanel;
    @FXML
    private HBox root;
    @FXML
    private VBox gameArea;
    @FXML
    private GridPane ghostPanel;

    @FXML
    private GridPane holdBrickPanel;

    @FXML
    private GridPane nextBrickPanel;

    @FXML
    private GridPane gamePanel;

    @FXML
    private Group groupNotification;

    @FXML
    private GridPane brickPanel;

    @FXML
    private GameOverPanel gameOverPanel;

    @FXML
    private PausePanel pausePanel;

    @FXML
    private Label scoreLabel;

    private ViewModel viewModel;
    private SettingsViewModel settingsViewModel;
    private ControlPanelView controlPanelView;
    private final HudRenderer hudRenderer = new HudRenderer();
    private GameRenderer gameRenderer;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Font.loadFont(getClass().getClassLoader().getResource("digital.ttf").toExternalForm(), 38);
        gameArea.setMinSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        gamePanel.setFocusTraversable(true);
        gamePanel.setOnKeyPressed(e -> viewModel.handleKey(e));
        Platform.runLater(()->{
           gamePanel.requestFocus();
        });
        groupNotification.setLayoutY(200);
        gameOverPanel.setVisible(false);
        pausePanel.setVisible(false);
    }

    public void setGameViewModel(ViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void bindGameViewModel() {
        pausePanel.visibleProperty().bind(viewModel.pauseProperty());
        gameOverPanel.visibleProperty().bind(viewModel.gameOverProperty());
        scoreLabel.textProperty().bind(viewModel.scoreProperty().asString());
        viewModel.nextBrickProperty().addListener((obs, oldVal, newVal) -> {
            hudRenderer.refreshPreview(nextBrickPanel, newVal);
        });
        viewModel.holdBrickProperty().addListener((obs, oldVal, newVal) -> {
            hudRenderer.refreshPreview(holdBrickPanel, newVal);
        });
    }

    public void setSettingsViewModel(SettingsViewModel settingsViewModel) {
        this.settingsViewModel = settingsViewModel;

    }

    public void bindSettingsViewModel() {
        this.controlPanelView = new ControlPanelView(viewModel, settingsViewModel, controlsPanel);
        controlPanelView.initControlsPanel();
    }

    public void initHud() {
        if (viewModel == null) {
            return;
        }
        hudRenderer.initPreview(nextBrickPanel, viewModel.nextBrickProperty().getValue());
        hudRenderer.initPreview(holdBrickPanel, viewModel.holdBrickProperty().getValue());
    }

    public void setGameRenderer(GameRenderer gameRenderer) {
        this.gameRenderer = gameRenderer;
        gameRenderer.setGamePanel(gamePanel);
        gameRenderer.setBrickPanel(brickPanel);
        gameRenderer.setGhostPanel(ghostPanel);
        gameRenderer.setGroupNotification(groupNotification);
    }
}
