package com.tetris.logic;

import com.tetris.util.MatrixOperations;

public record ViewData(int[][] brickData, int xPosition, int yPosition, int[][] nextBrickData, int[][] holdBrickData) {

    @Override
    public int[][] brickData() {
        return MatrixOperations.copy(brickData);
    }

    @Override
    public int[][] nextBrickData() {
        return MatrixOperations.copy(nextBrickData);
    }

    @Override
    public int[][] holdBrickData() {
        return MatrixOperations.copy(holdBrickData);
    }
}
