package com.tetris.controller;

import com.tetris.SceneManager;
import com.tetris.SceneType;
import com.tetris.input.EventSource;
import com.tetris.input.EventType;
import com.tetris.logic.Board;
import com.tetris.logic.ClearRow;
import com.tetris.logic.GameModel;
import com.tetris.logic.SimpleBoard;
import com.tetris.view.GameRenderer;
import javafx.animation.AnimationTimer;

public class CreativeGameController implements InputEventListener {

    private double SPEED = 2.3; // Rows per Second
    private static final int SCORE_PER_ROW = 1;
    private static final int BASE_BONUS = 50;
    private final Board board = new SimpleBoard(25, 10);

    private final GameRenderer gameRenderer;
    private final GameModel gameModel;

    private AnimationTimer gameLoop;

    public CreativeGameController(GameRenderer gameRenderer, GameModel gameModel) {
        this.gameModel = gameModel;
        gameModel.setScore(board.getScore());
        newBrick();

        this.gameRenderer = gameRenderer;
        gameRenderer.initGameView(board.getBoardMatrix(), board.getViewData());
    }

    public void start() {
        gameLoop = new AnimationTimer() {
            private long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (lastUpdate == 0) {
                    lastUpdate = now;
                    return;
                }

                long interval = (long) (1.0/SPEED * 1_000_000_000);
                if (now - lastUpdate >= interval) {
                    onDownEvent(EventSource.THREAD);
                    lastUpdate = now;
                }
            }
        };

        gameLoop.start();
    }

    @Override
    public void handleEvent(EventType eventType) {
        switch (eventType) {
            case EventType.MOVE_DOWN -> onDownEvent(EventSource.USER);
            case EventType.MOVE_LEFT -> onLeftEvent();
            case EventType.MOVE_RIGHT -> onRightEvent();
            case EventType.MOVE_UP -> onUpEvent();
            case EventType.MOVE_ROTATE -> onRotateEvent();
            case EventType.THROW -> onThrowEvent();
            case EventType.PLACE -> onPlaceEvent();
            case EventType.NEW_GAME -> createNewGame();
            case EventType.EXIT -> exit();
            default -> System.err.println("Game event not handled by this game controller.");
        }
    }

    private void onPlaceEvent() {
        handleBrickOnFloor();
    }

    private void onUpEvent() {
        if (gameModel.pauseProperty().getValue() || gameModel.gameOverProperty().getValue()) {
            return;
        }
        board.moveBrickUp();
        refresh();
    }

    private void exit() {
        SceneManager.getInstance().switchTo(SceneType.MENU);
    }

    private void onDownEvent(EventSource eventSource) {
        boolean canMove = board.moveBrickDown();
        refresh();
    }

    private void onLeftEvent() {
        board.moveBrickLeft();
        refresh();
    }

    private void onRightEvent() {
        board.moveBrickRight();
        refresh();
    }

    private void onRotateEvent() {
        board.rotateLeftBrick();
        refresh();
    }

    private void onThrowEvent() {
        board.throwBrick();
        gameModel.setHold(board.getViewData().holdBrickData());
        gameModel.setCanHold(false);
        gameModel.setNextBrick(board.getViewData().nextBrickData());

        refresh();

    }

    private void handleBrickOnFloor() {
        board.mergeBrickToBackground();
        checkClearedRows();

        if (newBrick()) {
            gameOver();
        }
        refresh();
    }

    private void checkClearedRows() {
        ClearRow clearRow = board.clearRows();
        if (clearRow.linesRemoved() > 0) {
            int scoreBonus = BASE_BONUS * clearRow.linesRemoved() * clearRow.linesRemoved();
            board.addScore(scoreBonus);
            gameRenderer.sendNotification(scoreBonus);
        }
    }

    private void gameOver() {
        gameLoop.stop();
        gameModel.setIsGameOver(true);
    }

    private void createNewGame() {
        gameModel.setIsGameOver(false);
        gameModel.setIsPause(false);
        board.newGame();
        resetHudBricks();
        refresh();
        gameLoop.start();
    }

    private void onPauseEvent() {
        if (gameModel.pauseProperty().getValue()) {
            gameLoop.start();
            gameModel.setIsPause(false);
            gameRenderer.requestFocus();
        } else {
            gameLoop.stop();
            gameModel.setIsPause(true);
        }
    }

    private boolean newBrick() {
        boolean collisionsOnNewBrick = board.createNewBrick();
        resetHudBricks();
        return collisionsOnNewBrick;
    }

    private void resetHudBricks() {
        gameModel.setNextBrick(board.getViewData().nextBrickData());
        gameModel.setHold(board.getViewData().holdBrickData());
        gameModel.setCanHold(true);
    }

    private void refresh() {
        gameRenderer.refreshGameBackground(board.getBoardMatrix());
        gameRenderer.refreshBrick(board.getViewData());
        gameRenderer.refreshGhost(board.getViewData(), -(board.getBoardMatrix().length+10));
    }
}
